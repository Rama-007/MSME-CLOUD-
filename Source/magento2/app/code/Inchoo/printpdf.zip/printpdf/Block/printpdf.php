<?php
namespace Inchoo\printpdf\Block;
class printpdf extends \Magento\Framework\View\Element\Template
{

    public function getHelloWorldTxt()
    {
        return 'Hello world!';
    }
}
?>